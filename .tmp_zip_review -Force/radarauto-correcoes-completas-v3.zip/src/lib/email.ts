// ─────────────────────────────────────────────────────────────
// email.ts — Email transacional via Resend
// Se RESEND_API_KEY não estiver configurado, loga e retorna.
// ─────────────────────────────────────────────────────────────

const RESEND_API_KEY = process.env.RESEND_API_KEY?.trim()
const FROM = process.env.RESEND_FROM?.trim() || 'RadarAuto <noreply@radarauto.com.br>'
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://radarauto.com.br'

async function sendEmail(to: string, subject: string, html: string): Promise<boolean> {
  if (!RESEND_API_KEY) {
    console.log(`[email] RESEND_API_KEY não configurado — email não enviado para ${to}: ${subject}`)
    return false
  }

  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({ from: FROM, to, subject, html }),
    })

    if (!res.ok) {
      const err = await res.text()
      console.error(`[email] Falha ao enviar para ${to}: ${err}`)
      return false
    }

    console.log(`[email] Enviado para ${to}: ${subject}`)
    return true
  } catch (err) {
    console.error('[email] Erro de rede:', err)
    return false
  }
}

function baseTemplate(content: string) {
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f5f5f3;color:#1a1a1a}
  .wrap{max-width:560px;margin:32px auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e8e8e5}
  .header{background:#185FA5;padding:24px 32px;display:flex;align-items:center;gap:12px}
  .logo{background:#fff;border-radius:8px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:16px;color:#185FA5}
  .logo-text{color:#fff;font-size:18px;font-weight:700}
  .body{padding:32px}
  .title{font-size:22px;font-weight:700;margin-bottom:12px}
  .text{font-size:14px;color:#555;line-height:1.7;margin-bottom:16px}
  .btn{display:inline-block;background:#185FA5;color:#fff;text-decoration:none;padding:13px 28px;border-radius:8px;font-size:14px;font-weight:600}
  .footer{border-top:1px solid #f0f0ee;padding:20px 32px;font-size:12px;color:#aaa;text-align:center}
  .highlight{background:#EAF3DE;border-radius:8px;padding:14px 18px;border-left:4px solid #639922;margin:16px 0}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div class="logo">R</div>
    <div class="logo-text">RadarAuto</div>
  </div>
  <div class="body">${content}</div>
  <div class="footer">RadarAuto — Radar inteligente de oportunidades veiculares<br/>
  <a href="${APP_URL}/perfil" style="color:#185FA5;">Gerenciar preferências</a> · <a href="${APP_URL}/assinatura" style="color:#185FA5;">Minha assinatura</a></div>
</div>
</body></html>`
}

export async function sendWelcomeEmail(email: string, name: string): Promise<{ sent: boolean }> {
  const html = baseTemplate(`
    <div class="title">Bem-vindo ao RadarAuto, ${name.split(' ')[0]}! 🎯</div>
    <p class="text">Sua conta foi criada com sucesso. Você tem <strong>7 dias gratuitos</strong> para explorar todas as funcionalidades.</p>
    <div class="highlight">
      <strong>O que fazer agora:</strong><br/>
      1. Configure seu radar com os modelos que você revende<br/>
      2. Defina os filtros de preço, km e risco<br/>
      3. Ative o Telegram para receber alertas em tempo real
    </div>
    <p class="text">O sistema vai varrer OLX, Facebook Marketplace e Webmotors automaticamente e te avisar quando encontrar oportunidades.</p>
    <a href="${APP_URL}/dashboard" class="btn">Acessar meu painel →</a>
  `)
  const sent = await sendEmail(email, 'Bem-vindo ao RadarAuto! Seus 7 dias gratuitos começaram', html)
  return { sent }
}

export async function sendTrialEndingEmail(email: string, name: string, daysLeft: number): Promise<{ sent: boolean }> {
  const html = baseTemplate(`
    <div class="title">⏰ Seu período gratuito encerra em ${daysLeft} dia${daysLeft === 1 ? '' : 's'}</div>
    <p class="text">Olá, ${name.split(' ')[0]}! Seu trial do RadarAuto está quase acabando.</p>
    <div class="highlight">
      Continue encontrando oportunidades de revenda com o <strong>Plano Pro por R$ 197/mês</strong>.<br/>
      Ou escolha o plano que melhor se encaixa no seu perfil.
    </div>
    <a href="${APP_URL}/assinatura" class="btn">Ver planos e assinar →</a>
    <p class="text" style="margin-top:16px;font-size:12px;">Após o trial, o acesso fica limitado. Assine agora para manter tudo funcionando.</p>
  `)
  const sent = await sendEmail(email, `⏰ Seu trial RadarAuto encerra em ${daysLeft} dia${daysLeft === 1 ? '' : 's'}`, html)
  return { sent }
}

export async function sendAlertEmail(email: string, listing: {
  title: string; price: number; city?: string; opportunityScore?: number; sourceUrl?: string; estimatedMargin?: number
}): Promise<{ sent: boolean }> {
  const html = baseTemplate(`
    <div class="title">🚨 Nova oportunidade encontrada!</div>
    <div class="highlight">
      <strong>${listing.title}</strong><br/>
      💰 R$ ${listing.price.toLocaleString('pt-BR')}<br/>
      ${listing.city ? `📍 ${listing.city}<br/>` : ''}
      ${listing.opportunityScore ? `⭐ Score: ${listing.opportunityScore}/100<br/>` : ''}
      ${listing.estimatedMargin && listing.estimatedMargin > 0 ? `📈 Margem est.: R$ ${Math.round(listing.estimatedMargin).toLocaleString('pt-BR')}` : ''}
    </div>
    ${listing.sourceUrl ? `<a href="${listing.sourceUrl}" class="btn">Ver anúncio →</a>` : ''}
    <p class="text" style="margin-top:16px;"><a href="${APP_URL}/oportunidades" style="color:#185FA5;">Ver todas as oportunidades no RadarAuto</a></p>
  `)
  const sent = await sendEmail(email, `🚨 ${listing.title} — R$ ${listing.price.toLocaleString('pt-BR')} | RadarAuto`, html)
  return { sent }
}
