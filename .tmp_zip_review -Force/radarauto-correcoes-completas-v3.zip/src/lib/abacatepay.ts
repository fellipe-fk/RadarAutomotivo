// ─────────────────────────────────────────────────────────────
// abacatepay.ts — Integração com Abacatepay
// Substitui completamente o Asaas.
// Suporta assinatura mensal e anual com PIX e cartão.
// ─────────────────────────────────────────────────────────────

const BASE_URL = process.env.ABACATEPAY_BASE_URL?.trim() || 'https://api.abacatepay.com/v1'
const API_KEY = process.env.ABACATEPAY_API_KEY?.trim()

// ── Planos disponíveis ────────────────────────────────────────

export const PLANOS = {
  BASICO_MENSAL: { id: 'basico_mensal', nome: 'Básico Mensal', valor: 9700, ciclo: 'MONTHLY' as const, plano: 'BASICO' },
  BASICO_ANUAL:  { id: 'basico_anual',  nome: 'Básico Anual',  valor: 93100, ciclo: 'YEARLY' as const, plano: 'BASICO' },
  PRO_MENSAL:    { id: 'pro_mensal',    nome: 'Pro Mensal',    valor: 19700, ciclo: 'MONTHLY' as const, plano: 'PRO' },
  PRO_ANUAL:     { id: 'pro_anual',     nome: 'Pro Anual',     valor: 189100, ciclo: 'YEARLY' as const, plano: 'PRO' },
  AGENCIA_MENSAL: { id: 'agencia_mensal', nome: 'Agência Mensal', valor: 49700, ciclo: 'MONTHLY' as const, plano: 'AGENCIA' },
  AGENCIA_ANUAL:  { id: 'agencia_anual',  nome: 'Agência Anual',  valor: 477100, ciclo: 'YEARLY' as const, plano: 'AGENCIA' },
} as const

export type PlanoId = keyof typeof PLANOS

// ── Tipos da API ──────────────────────────────────────────────

type AbacatepayCustomer = {
  id: string
  name: string
  email: string
  cellphone?: string
}

type AbacatepaySubscription = {
  id: string
  status: 'ACTIVE' | 'CANCELLED' | 'EXPIRED' | 'PENDING'
  customer: { id: string }
  planId: string
  currentPeriodEnd: string
  checkoutUrl?: string
}

type AbacatepayWebhookPayload = {
  event: 'subscription.activated' | 'subscription.renewed' | 'subscription.cancelled' | 'subscription.expired' | 'payment.confirmed'
  data: {
    subscription?: { id: string; status: string; planId: string; customerId: string; currentPeriodEnd: string }
    customer?: { id: string }
    payment?: { id: string; amount: number; status: string; subscriptionId?: string }
  }
}

// ── Helpers ───────────────────────────────────────────────────

async function abacateRequest<T>(path: string, method: 'GET' | 'POST' | 'DELETE' = 'GET', body?: object): Promise<T> {
  if (!API_KEY) throw new Error('ABACATEPAY_API_KEY não configurado.')

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${API_KEY}`,
    },
    body: body ? JSON.stringify(body) : undefined,
    cache: 'no-store',
  })

  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Abacatepay ${method} ${path} → ${res.status}: ${text}`)
  }

  return res.json() as Promise<T>
}

// ── Funções públicas ──────────────────────────────────────────

/**
 * Cria ou atualiza um cliente no Abacatepay.
 */
export async function criarOuBuscarCliente(params: {
  name: string
  email: string
  phone?: string
}): Promise<AbacatepayCustomer | null> {
  if (!API_KEY) return null

  try {
    const customer = await abacateRequest<AbacatepayCustomer>('/customers', 'POST', {
      name: params.name,
      email: params.email,
      cellphone: params.phone?.replace(/\D/g, '') || undefined,
    })
    return customer
  } catch (err) {
    console.error('[abacatepay] Falha ao criar customer:', err)
    return null
  }
}

/**
 * Cria uma assinatura e retorna a URL de checkout para o usuário pagar.
 */
export async function criarAssinatura(params: {
  customerId: string
  planoId: PlanoId
  successUrl: string
  cancelUrl: string
}): Promise<{ subscriptionId: string; checkoutUrl: string } | null> {
  if (!API_KEY) return null

  try {
    const plano = PLANOS[params.planoId]
    const subscription = await abacateRequest<AbacatepaySubscription>('/subscriptions', 'POST', {
      customerId: params.customerId,
      plan: {
        id: plano.id,
        name: plano.nome,
        amount: plano.valor, // em centavos
        interval: plano.ciclo,
      },
      successUrl: params.successUrl,
      cancelUrl: params.cancelUrl,
    })

    return {
      subscriptionId: subscription.id,
      checkoutUrl: subscription.checkoutUrl || `${BASE_URL}/checkout/${subscription.id}`,
    }
  } catch (err) {
    console.error('[abacatepay] Falha ao criar assinatura:', err)
    return null
  }
}

/**
 * Cancela uma assinatura.
 */
export async function cancelarAssinatura(subscriptionId: string): Promise<boolean> {
  if (!API_KEY || !subscriptionId) return false

  try {
    await abacateRequest(`/subscriptions/${subscriptionId}`, 'DELETE')
    return true
  } catch (err) {
    console.error('[abacatepay] Falha ao cancelar:', err)
    return false
  }
}

/**
 * Verifica a assinatura ativa de um customer.
 */
export async function buscarAssinatura(subscriptionId: string): Promise<AbacatepaySubscription | null> {
  if (!API_KEY || !subscriptionId) return null

  try {
    return await abacateRequest<AbacatepaySubscription>(`/subscriptions/${subscriptionId}`)
  } catch {
    return null
  }
}

/**
 * Processa payload de webhook do Abacatepay.
 * Retorna ação e dados relevantes para atualizar o banco.
 */
export function processarWebhook(payload: AbacatepayWebhookPayload): {
  action: 'activate' | 'renew' | 'cancel' | 'expire' | 'unknown'
  subscriptionId?: string
  customerId?: string
  planId?: string
  periodEnd?: Date
} {
  const { event, data } = payload

  if (event === 'subscription.activated' || event === 'payment.confirmed') {
    const sub = data.subscription
    return {
      action: 'activate',
      subscriptionId: sub?.id || data.payment?.subscriptionId,
      customerId: sub?.customerId || data.customer?.id,
      planId: sub?.planId,
      periodEnd: sub?.currentPeriodEnd ? new Date(sub.currentPeriodEnd) : undefined,
    }
  }

  if (event === 'subscription.renewed') {
    const sub = data.subscription
    return {
      action: 'renew',
      subscriptionId: sub?.id,
      customerId: sub?.customerId,
      planId: sub?.planId,
      periodEnd: sub?.currentPeriodEnd ? new Date(sub.currentPeriodEnd) : undefined,
    }
  }

  if (event === 'subscription.cancelled') {
    return { action: 'cancel', subscriptionId: data.subscription?.id, customerId: data.subscription?.customerId }
  }

  if (event === 'subscription.expired') {
    return { action: 'expire', subscriptionId: data.subscription?.id, customerId: data.subscription?.customerId }
  }

  return { action: 'unknown' }
}

export function abacatepayConfigured(): boolean {
  return !!API_KEY
}
