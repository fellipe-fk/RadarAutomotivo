import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { requireAuth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { criarOuBuscarCliente, criarAssinatura, PLANOS, type PlanoId } from '@/lib/abacatepay'

const checkoutSchema = z.object({
  planoId: z.enum(['BASICO_MENSAL','BASICO_ANUAL','PRO_MENSAL','PRO_ANUAL','AGENCIA_MENSAL','AGENCIA_ANUAL']),
})

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth(req)
    const dbUser = await prisma.user.findUniqueOrThrow({ where: { id: user.id } })
    const body = await req.json()
    const { planoId } = checkoutSchema.parse(body)

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

    // Criar ou reutilizar customer no Abacatepay
    let customerId = dbUser.asaasCustomerId // campo reaproveitado

    if (!customerId) {
      const customer = await criarOuBuscarCliente({
        name: dbUser.name,
        email: dbUser.email,
        phone: dbUser.phone || undefined,
      })
      if (!customer?.id) {
        return NextResponse.json({ error: 'Falha ao criar conta de pagamento. Tente novamente.' }, { status: 500 })
      }
      customerId = customer.id
      await prisma.user.update({ where: { id: user.id }, data: { asaasCustomerId: customerId } })
    }

    // Criar assinatura e obter URL de checkout
    const result = await criarAssinatura({
      customerId,
      planoId: planoId as PlanoId,
      successUrl: `${appUrl}/assinatura?success=1&plano=${PLANOS[planoId as PlanoId].plano}`,
      cancelUrl: `${appUrl}/assinatura?cancelled=1`,
    })

    if (!result) {
      return NextResponse.json({ error: 'Falha ao criar assinatura. Tente novamente em instantes.' }, { status: 500 })
    }

    // Salvar subscription ID pendente
    await prisma.user.update({
      where: { id: user.id },
      data: { asaasSubscriptionId: result.subscriptionId },
    })

    return NextResponse.json({ checkoutUrl: result.checkoutUrl })
  } catch (err) {
    console.error('[checkout]', err)
    return NextResponse.json({ error: 'Erro interno no checkout' }, { status: 500 })
  }
}
