import { NextRequest, NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { cancelarAssinatura } from '@/lib/abacatepay'

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth(req)
    const dbUser = await prisma.user.findUniqueOrThrow({ where: { id: user.id } })
    if (!dbUser.asaasSubscriptionId) {
      return NextResponse.json({ error: 'Nenhuma assinatura ativa encontrada.' }, { status: 400 })
    }
    const ok = await cancelarAssinatura(dbUser.asaasSubscriptionId)
    if (!ok) {
      return NextResponse.json({ error: 'Falha ao cancelar. Tente novamente ou contate o suporte.' }, { status: 500 })
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { assinaturaStatus: 'CANCELADA' },
    })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
