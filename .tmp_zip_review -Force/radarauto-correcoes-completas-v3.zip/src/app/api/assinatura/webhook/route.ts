import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'
import { prisma } from '@/lib/prisma'
import { processarWebhook } from '@/lib/abacatepay'

// Mapa de planId do Abacatepay → plano interno
const PLANO_MAP: Record<string, 'BASICO' | 'PRO' | 'AGENCIA'> = {
  basico_mensal: 'BASICO', basico_anual: 'BASICO',
  pro_mensal: 'PRO', pro_anual: 'PRO',
  agencia_mensal: 'AGENCIA', agencia_anual: 'AGENCIA',
}

export async function POST(req: NextRequest) {
  const secret = process.env.ABACATEPAY_WEBHOOK_SECRET
  const rawBody = await req.text()

  // Verificar assinatura HMAC do Abacatepay
  if (secret) {
    const sig = req.headers.get('abacatepay-signature') || req.headers.get('x-webhook-signature') || ''
    const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex')
    const sigBuf = Buffer.from(sig.replace('sha256=', ''))
    const expBuf = Buffer.from(expected)
    if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
      console.warn('[webhook] Assinatura inválida')
      return NextResponse.json({ error: 'Assinatura inválida' }, { status: 403 })
    }
  }

  let payload: unknown
  try { payload = JSON.parse(rawBody) } catch {
    return NextResponse.json({ error: 'Payload inválido' }, { status: 400 })
  }

  const evento = processarWebhook(payload as Parameters<typeof processarWebhook>[0])
  console.log(`[webhook] Evento: ${(payload as {event?: string}).event} → action: ${evento.action}`)

  try {
    if (evento.action === 'activate' || evento.action === 'renew') {
      const plano = PLANO_MAP[evento.planId || ''] || 'BASICO'
      const periodEnd = evento.periodEnd || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)

      // Buscar usuário pelo customerId do Abacatepay
      if (evento.customerId) {
        await prisma.user.updateMany({
          where: { asaasCustomerId: evento.customerId }, // campo reaproveitado para customerId Abacatepay
          data: {
            assinaturaStatus: 'ATIVA',
            plano,
            assinaturaEndsAt: periodEnd,
            asaasSubscriptionId: evento.subscriptionId,
          },
        })
      }
    }

    if (evento.action === 'cancel') {
      if (evento.subscriptionId) {
        await prisma.user.updateMany({
          where: { asaasSubscriptionId: evento.subscriptionId },
          data: { assinaturaStatus: 'CANCELADA' },
        })
      }
    }

    if (evento.action === 'expire') {
      if (evento.subscriptionId) {
        await prisma.user.updateMany({
          where: { asaasSubscriptionId: evento.subscriptionId },
          data: { assinaturaStatus: 'ENCERRADA' },
        })
      }
    }

    return NextResponse.json({ received: true })
  } catch (err) {
    console.error('[webhook] Erro ao processar:', err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}
