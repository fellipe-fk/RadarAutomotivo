// ─────────────────────────────────────────────────────────────
// /api/radar/auto-scan
// Chamado pelo Vercel Cron a cada 30 min (vercel.json).
// NÃO usa requireAuth — autentica via CRON_SECRET no header.
// Processa todos os usuários com radar ativo cuja frequência
// configurada esteja vencida desde o último scan.
// ─────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { normalizeRadarConfig } from '@/lib/radar'
import { buildAlertMessage } from '@/lib/analyzer'
import { analysisRiskMap, parseEstimatedMarginValue, runAnalysisWithFallback } from '@/lib/listing-analysis'
import { extractListingFromUrl, NotAVehicleError } from '@/lib/listing-extractor'
import { matchesRadar } from '@/lib/radar'
import { sendTelegramAlert } from '@/lib/telegram'

export const runtime = 'nodejs'
export const maxDuration = 60

function inferVehicleType(value: string): 'MOTO' | 'CARRO' {
  const n = value.toLowerCase()
  const motoTokens = ['moto', 'motocicleta', 'xre', 'titan', 'cg ', 'biz', 'fazer', 'hornet', 'cb 500', 'cb500', 'bros', 'nmax', 'pcx', 'lander', 'tenere', 'scooter']
  return motoTokens.some((t) => n.includes(t)) ? 'MOTO' : 'CARRO'
}

function buildSearchUrls(modelo: string, fonte: string): string[] {
  const q = encodeURIComponent(modelo)
  switch (fonte) {
    case 'olx': return [
      `https://www.olx.com.br/autos-e-pecas/carros-vans-e-utilitarios?q=${q}`,
      `https://www.olx.com.br/autos-e-pecas/motos?q=${q}`,
    ]
    case 'webmotors': return [`https://www.webmotors.com.br/carros/estoque?busca=${q}`]
    case 'icarros': return [`https://www.icarros.com.br/ache/lista.jsp?palavra=${q}`]
    default: return []
  }
}

async function extractLinksFromPage(searchUrl: string, modelo: string): Promise<string[]> {
  try {
    const jinaUrl = `https://r.jina.ai/${searchUrl}`
    const res = await fetch(jinaUrl, {
      headers: { Accept: 'application/json' },
      signal: AbortSignal.timeout(20000),
    })
    if (!res.ok) return []
    const data = await res.json() as { data?: { content?: string; links?: Record<string, string> } }
    const links = data.data?.links || {}
    const result: string[] = []
    for (const [url] of Object.entries(links)) {
      try {
        const parsed = new URL(url)
        const search = new URL(searchUrl)
        const pathDepth = parsed.pathname.split('/').filter(Boolean).length
        if (parsed.hostname.includes(search.hostname.replace('www.', '')) && pathDepth >= 3) {
          result.push(url)
        }
      } catch { continue }
    }
    return result.slice(0, 5)
  } catch { return [] }
}

// Validação de preço mínimo por tipo de veículo
function isValidPrice(price: number, type: 'MOTO' | 'CARRO'): boolean {
  if (type === 'MOTO') return price >= 2000 && price <= 500000
  return price >= 5000 && price <= 5000000
}

export async function GET(req: NextRequest) {
  // Autenticação via CRON_SECRET — sem cookie de sessão
  const authHeader = req.headers.get('authorization')
  const cronSecret = process.env.CRON_SECRET

  if (cronSecret && authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  const now = new Date()
  console.log(`[auto-scan] Iniciando às ${now.toISOString()}`)

  try {
    // Buscar todos usuários com radar ativo e assinatura válida
    const users = await prisma.user.findMany({
      where: {
        assinaturaStatus: { in: ['ATIVA', 'TRIAL'] },
        radarConfig: { ativo: true },
      },
      include: { radarConfig: true },
      select: {
        id: true,
        telegramEnabled: true,
        telegramChatId: true,
        radarConfig: true,
      },
    })

    const results: Array<{ userId: string; status: string; analyzed?: number; alerted?: number; reason?: string }> = []

    for (const user of users) {
      const config = user.radarConfig
      if (!config) { results.push({ userId: user.id, status: 'skip', reason: 'sem config' }); continue }

      // Checar frequência — não rodar antes do tempo configurado
      const lastListing = await prisma.listing.findFirst({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
        select: { createdAt: true },
      })

      const frequenciaMs = Math.max(30, config.frequenciaMin || 60) * 60 * 1000
      const elapsed = lastListing ? now.getTime() - lastListing.createdAt.getTime() : Infinity

      if (elapsed < frequenciaMs) {
        const waitMin = Math.round((frequenciaMs - elapsed) / 60000)
        results.push({ userId: user.id, status: 'skip', reason: `aguardando ${waitMin}min` })
        continue
      }

      const normalized = normalizeRadarConfig(config)
      let analyzed = 0
      let alerted = 0

      // Coletar URLs a processar
      const manualUrls = (config.seedUrls || []).map((u: string) => u.trim()).filter(Boolean).slice(0, 10)
      const searchUrls: string[] = []

      if (normalized.modelos.length > 0) {
        for (const modelo of normalized.modelos.slice(0, 2)) {
          for (const fonte of normalized.fontes.filter((f: string) => f !== 'manual').slice(0, 2)) {
            for (const sUrl of buildSearchUrls(modelo, fonte)) {
              const links = await extractLinksFromPage(sUrl, modelo)
              searchUrls.push(...links)
            }
          }
        }
      }

      const allUrls = [...new Set([...manualUrls, ...searchUrls])].slice(0, 15)
      if (allUrls.length === 0) { results.push({ userId: user.id, status: 'skip', reason: 'sem URLs' }); continue }

      for (const sourceUrl of allUrls) {
        try {
          const extracted = await extractListingFromUrl(sourceUrl)
          const title = extracted.title || 'Anúncio monitorado'
          const type = inferVehicleType(`${title} ${extracted.brand || ''} ${extracted.model || ''}`)

          // Validar preço mínimo — evitar captura errada de preços
          if (!extracted.price || !isValidPrice(extracted.price, type)) continue

          const existing = await prisma.listing.findFirst({ where: { userId: user.id, sourceUrl: extracted.resolvedUrl } })
          const baseData = {
            title, description: extracted.description, price: extracted.price,
            type, source: extracted.source, sourceUrl: extracted.resolvedUrl,
            imageUrls: extracted.imageUrls, brand: extracted.brand, model: extracted.model,
            year: extracted.year, mileage: extracted.mileage, city: extracted.city, state: extracted.state,
            status: 'PENDING' as const,
          }

          const listing = existing
            ? await prisma.listing.update({ where: { id: existing.id }, data: baseData })
            : await prisma.listing.create({ data: { userId: user.id, ...baseData } })

          const { analysis } = await runAnalysisWithFallback({ type, title, description: extracted.description, price: extracted.price, mileage: extracted.mileage || undefined, year: extracted.year || undefined, city: extracted.city || undefined, sourceUrl: extracted.resolvedUrl, sourceContext: extracted.sourceContext, brand: extracted.brand || undefined, model: extracted.model || undefined })
          const riskLevel = analysisRiskMap[analysis.nivel_risco] || 'MEDIUM'
          const estimatedMargin = parseEstimatedMarginValue(analysis.margem_estimada)

          const updated = await prisma.listing.update({
            where: { id: listing.id },
            data: { title: analysis.titulo || listing.title, opportunityScore: analysis.score_oportunidade, riskScore: analysis.score_risco, riskLevel, aiSummary: analysis.resumo, positiveSignals: analysis.sinais_positivos || [], alertSignals: analysis.sinais_alerta || [], fipePrice: analysis.fipe_estimada, avgMarketPrice: analysis.media_mercado, estimatedMargin, status: 'ANALYZED' },
          })

          analyzed++

          // Alerta Telegram se passar no radar e margem positiva
          if (matchesRadar(updated, normalized) && !updated.alertSent && (estimatedMargin || 0) > 0 && user.telegramEnabled && user.telegramChatId) {
            const message = buildAlertMessage({ title: updated.title, price: updated.price, city: updated.city || undefined, distanceKm: updated.distanceKm || undefined, opportunityScore: updated.opportunityScore || undefined, riskLevel: updated.riskLevel || undefined, estimatedMargin: updated.estimatedMargin || undefined, aiSummary: updated.aiSummary || undefined, sourceUrl: updated.sourceUrl || undefined })
            const sent = await sendTelegramAlert(message, user.telegramChatId)
            if (sent) {
              await prisma.listing.update({ where: { id: updated.id }, data: { alertSent: true, status: 'ALERTED' } })
              await prisma.alert.create({ data: { userId: user.id, listingId: updated.id, channel: 'telegram', message, sent: true, sentAt: new Date() } })
              alerted++
            }
          }
        } catch (err) {
          if (err instanceof NotAVehicleError) continue
          console.warn(`[auto-scan] URL falhou: ${sourceUrl}`, err instanceof Error ? err.message : err)
        }
      }

      results.push({ userId: user.id, status: 'done', analyzed, alerted })
    }

    console.log(`[auto-scan] Concluído: ${results.filter(r => r.status === 'done').length} usuários processados`)
    return NextResponse.json({ ok: true, timestamp: now.toISOString(), results })
  } catch (error) {
    console.error('[auto-scan] Erro crítico:', error)
    return NextResponse.json({ error: 'Erro interno no auto-scan' }, { status: 500 })
  }
}
