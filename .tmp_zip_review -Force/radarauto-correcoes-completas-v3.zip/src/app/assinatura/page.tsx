'use client'

import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import Sidebar from '@/components/ui/Sidebar'

type UserPlan = {
  plano: string
  assinaturaStatus: string
  trialEndsAt?: string | null
  assinaturaEndsAt?: string | null
  name: string
  email: string
}

type Pagamento = {
  id: string
  createdAt: string
  descricao: string
  valor: number
  status: string
}

function formatPlan(plano?: string) {
  if (plano === 'AGENCIA') return 'Agência'
  if (plano === 'PRO') return 'Pro'
  return 'Básico'
}

function formatStatus(status?: string) {
  if (status === 'ATIVA') return { label: 'Ativa', color: '#27500A', bg: '#EAF3DE', border: '#97C459' }
  if (status === 'TRIAL') return { label: 'Trial', color: '#0C447C', bg: '#E6F1FB', border: '#85B7EB' }
  if (status === 'CANCELADA') return { label: 'Cancelada', color: '#A32D2D', bg: '#FCEAEA', border: '#F09595' }
  if (status === 'SUSPENSA') return { label: 'Suspensa', color: '#A32D2D', bg: '#FCEAEA', border: '#F09595' }
  return { label: 'Inativa', color: '#888', bg: '#F5F5F3', border: '#E8E8E5' }
}

const plans = [
  {
    key: 'BASICO',
    name: 'Básico',
    desc: 'Para compradores individuais',
    priceMonthly: 97,
    priceYearly: 931,
    planoIdMonthly: 'BASICO_MENSAL',
    planoIdYearly: 'BASICO_ANUAL',
    features: ['30 análises/mês', 'Radar 1 região', 'Alerta Telegram', 'Score IA básico'],
  },
  {
    key: 'PRO',
    name: 'Pro',
    desc: 'Para revendedores ativos',
    priceMonthly: 197,
    priceYearly: 1891,
    planoIdMonthly: 'PRO_MENSAL',
    planoIdYearly: 'PRO_ANUAL',
    featured: true,
    features: [
      'Análises ilimitadas',
      'Radar multi-região',
      'WhatsApp + Telegram',
      'Calculadora de revenda',
      'Rota Google Maps',
      'CRM completo',
      'Laudo veicular incluso',
    ],
  },
  {
    key: 'AGENCIA',
    name: 'Agência',
    desc: 'Para lojistas e equipes',
    priceMonthly: 497,
    priceYearly: 4771,
    planoIdMonthly: 'AGENCIA_MENSAL',
    planoIdYearly: 'AGENCIA_ANUAL',
    features: [
      'Até 5 usuários',
      'Multi-localidade',
      'Dashboard white-label',
      'Relatórios avançados',
      'API de integração',
      'Suporte prioritário',
    ],
  },
]

export default function AssinaturaPage() {
  const searchParams = useSearchParams()
  const [user, setUser] = useState<UserPlan | null>(null)
  const [pagamentos, setPagamentos] = useState<Pagamento[]>([])
  const [loading, setLoading] = useState(true)
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly')
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null)
  const [feedback, setFeedback] = useState('')

  const successParam = searchParams?.get('success')
  const cancelledParam = searchParams?.get('cancelled')

  useEffect(() => {
    async function fetchData() {
      try {
        const [userRes, pagRes] = await Promise.all([
          fetch('/api/auth/me'),
          fetch('/api/assinatura/historico').catch(() => ({ ok: false, json: async () => ({ pagamentos: [] }) })),
        ])
        if (userRes.ok) {
          const d = await userRes.json()
          setUser(d.user || null)
        }
        if (pagRes.ok) {
          const d = await (pagRes as Response).json()
          setPagamentos(d.pagamentos || [])
        }
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  useEffect(() => {
    if (successParam) setFeedback('✅ Assinatura ativada com sucesso! Bem-vindo ao RadarAuto Pro.')
    if (cancelledParam) setFeedback('Pagamento cancelado. Você pode tentar novamente quando quiser.')
  }, [successParam, cancelledParam])

  const statusInfo = useMemo(() => formatStatus(user?.assinaturaStatus), [user?.assinaturaStatus])
  const isCurrent = (planKey: string) => user?.plano === planKey
  const isActive = user?.assinaturaStatus === 'ATIVA' || user?.assinaturaStatus === 'TRIAL'

  const nextBilling = useMemo(() => {
    const date = user?.assinaturaEndsAt || user?.trialEndsAt
    if (date) return new Date(date).toLocaleDateString('pt-BR')
    const d = new Date()
    d.setDate(d.getDate() + 7)
    return d.toLocaleDateString('pt-BR')
  }, [user])

  async function handleCheckout(planoId: string) {
    setCheckoutLoading(planoId)
    setFeedback('')
    try {
      const res = await fetch('/api/assinatura/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planoId }),
      })
      const data = await res.json()
      if (!res.ok || !data.checkoutUrl) {
        setFeedback(data.error || 'Erro ao iniciar checkout. Tente novamente.')
        return
      }
      window.location.href = data.checkoutUrl
    } catch {
      setFeedback('Erro de conexão. Tente novamente.')
    } finally {
      setCheckoutLoading(null)
    }
  }

  async function handleCancelamento() {
    if (!confirm('Tem certeza? Você perderá o acesso ao final do período atual.')) return
    try {
      const res = await fetch('/api/assinatura/cancelar', { method: 'POST' })
      if (res.ok) {
        setFeedback('Assinatura cancelada. Você mantém o acesso até o fim do período.')
        window.location.reload()
      } else {
        setFeedback('Erro ao cancelar. Entre em contato com o suporte.')
      }
    } catch {
      setFeedback('Erro de conexão.')
    }
  }

  return (
    <div className="app-layout" data-page-id="assinatura">
      <Sidebar />
      <main className="main-content">

        <div className="page-header">
          <div>
            <h1 className="page-title">Assinatura</h1>
            <p className="page-subtitle">Gerencie seu plano e método de pagamento</p>
          </div>
        </div>

        {feedback && (
          <div className={`panel-notice ${feedback.startsWith('✅') ? 'panel-notice--success' : 'panel-notice--warn'}`}
            style={{ marginBottom: 20 }}>
            {feedback}
          </div>
        )}

        {/* Status da assinatura atual */}
        {!loading && user && (
          <div className="card" style={{
            background: statusInfo.bg,
            borderColor: statusInfo.border,
            maxWidth: 640,
            marginBottom: 24,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{
                width: 44, height: 44, background: statusInfo.color,
                borderRadius: 10, display: 'flex', alignItems: 'center',
                justifyContent: 'center', color: 'white', fontSize: 20, flexShrink: 0,
              }}>✓</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 15 }}>
                  Plano {formatPlan(user.plano)} — {statusInfo.label}
                </div>
                <div style={{ fontSize: 13, color: '#666', marginTop: 2 }}>
                  {user.assinaturaStatus === 'TRIAL'
                    ? `Trial gratuito · Encerra em ${nextBilling}`
                    : user.assinaturaStatus === 'ATIVA'
                      ? `Próxima cobrança: ${nextBilling}`
                      : `Status: ${statusInfo.label}`}
                </div>
              </div>
              {isActive && user.assinaturaStatus === 'ATIVA' && (
                <button className="btn btn-sm" onClick={handleCancelamento}
                  style={{ color: '#A32D2D', borderColor: '#A32D2D', flexShrink: 0 }}>
                  Cancelar
                </button>
              )}
            </div>
          </div>
        )}

        {/* Toggle mensal / anual */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
          <span style={{ fontSize: 14, fontWeight: 500 }}>Cobrança:</span>
          <div style={{
            display: 'flex', background: '#F5F5F3',
            borderRadius: 8, padding: 3, gap: 2,
          }}>
            <button
              onClick={() => setBillingCycle('monthly')}
              style={{
                padding: '6px 16px', borderRadius: 6, border: 'none',
                fontSize: 13, fontWeight: 600, cursor: 'pointer',
                background: billingCycle === 'monthly' ? '#fff' : 'transparent',
                color: billingCycle === 'monthly' ? '#185FA5' : '#888',
                boxShadow: billingCycle === 'monthly' ? '0 1px 4px rgba(0,0,0,.1)' : 'none',
                transition: 'all .15s',
              }}>
              Mensal
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              style={{
                padding: '6px 16px', borderRadius: 6, border: 'none',
                fontSize: 13, fontWeight: 600, cursor: 'pointer',
                background: billingCycle === 'yearly' ? '#fff' : 'transparent',
                color: billingCycle === 'yearly' ? '#185FA5' : '#888',
                boxShadow: billingCycle === 'yearly' ? '0 1px 4px rgba(0,0,0,.1)' : 'none',
                transition: 'all .15s',
              }}>
              Anual
            </button>
          </div>
          {billingCycle === 'yearly' && (
            <span style={{ fontSize: 12, fontWeight: 700, color: '#27500A', background: '#EAF3DE', padding: '3px 10px', borderRadius: 99 }}>
              20% de desconto
            </span>
          )}
        </div>

        {/* Cards de planos */}
        <div className="plan-cards" style={{ marginBottom: 32 }}>
          {plans.map(plan => {
            const current = isCurrent(plan.key)
            const price = billingCycle === 'monthly' ? plan.priceMonthly : plan.priceYearly
            const planoId = billingCycle === 'monthly' ? plan.planoIdMonthly : plan.planoIdYearly
            const isLoadingThis = checkoutLoading === planoId

            return (
              <div key={plan.key} className={`plan-card ${plan.featured ? 'featured' : ''}`}>
                <div className="plan-card__header">
                  <div>
                    <div className="plan-card__name">{plan.name}</div>
                    <div className="plan-card__description">{plan.desc}</div>
                  </div>
                  {current && (
                    <span className="badge badge--blue" style={{ flexShrink: 0 }}>Seu plano</span>
                  )}
                </div>

                <div style={{ margin: '16px 0' }}>
                  <span style={{ fontSize: 32, fontWeight: 800, color: '#1a1a1a' }}>
                    R$ {price.toLocaleString('pt-BR')}
                  </span>
                  <span style={{ fontSize: 13, color: '#888' }}>
                    /{billingCycle === 'monthly' ? 'mês' : 'ano'}
                  </span>
                  {billingCycle === 'yearly' && (
                    <div style={{ fontSize: 12, color: '#639922', marginTop: 2 }}>
                      = R$ {Math.round(price / 12)}/mês
                    </div>
                  )}
                </div>

                <ul className="plan-card__features">
                  {plan.features.map(f => (
                    <li key={f}>{f}</li>
                  ))}
                </ul>

                <button
                  className={`btn btn-sm ${plan.featured ? 'btn-primary' : ''}`}
                  style={{ width: '100%', justifyContent: 'center', marginTop: 16 }}
                  disabled={current || isLoadingThis || !isActive}
                  onClick={() => !current && handleCheckout(planoId)}
                >
                  {isLoadingThis
                    ? 'Redirecionando...'
                    : current
                      ? 'Plano atual'
                      : user?.plano === 'AGENCIA' && plan.key !== 'AGENCIA'
                        ? 'Fazer downgrade'
                        : 'Assinar agora'}
                </button>
              </div>
            )
          })}
        </div>

        {/* Histórico de cobranças — dados reais do banco */}
        <div className="card" style={{ maxWidth: 600 }}>
          <div className="card-title">Histórico de cobranças</div>
          {loading ? (
            <div className="panel-muted">Carregando...</div>
          ) : pagamentos.length === 0 ? (
            <div className="panel-muted">Nenhuma cobrança registrada ainda.</div>
          ) : (
            pagamentos.map(p => (
              <div key={p.id} className="subscription-history__row">
                <span style={{ fontSize: 13 }}>
                  {new Date(p.createdAt).toLocaleDateString('pt-BR')} — {p.descricao}
                </span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ color: '#27500A', fontWeight: 600, fontSize: 13 }}>
                    R$ {p.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                  <span className={`badge ${p.status === 'PAGO' ? 'badge--success' : 'badge--muted'}`}>
                    {p.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

      </main>
    </div>
  )
}
